<!doctype html>
<html lang="en" class="h-100">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
         {{-- inporting css in blad we kunnen php echo gebruiken of {{ }}--}}
<link rel="stylesheet" href="{{ asset('css/style.css') }}" type="text/css"> 

<style>

</style>
  </head>
  <body class="d-flex flex-column h-100">


<footer class="footer mt-auto py-3">
  <div class="container" style="color:white;">
        <a href="#!"><i class="fab fa-twitter fa-1x"></i></a>
        <a href="#!"><i class="fab fa-facebook fa-1x"></i></a>
        <a href="#!"><i class="fab fa-linkedin fa-1x"></i></a>
        <a href="#!"><i class="fab fa-github fa-1x"></i></a>
        <br>
      <a class="text-muted" href="#"> Subscribe </a>
        <br>
   <small>Copyright &copy; <script>document.write(new Date().getFullYear())</script></small> 
  </div>
</footer>

</body>
</html>