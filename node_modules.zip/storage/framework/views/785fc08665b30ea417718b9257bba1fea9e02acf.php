<?php $__env->startSection('content'); ?> 
<script>
let city = "brussels";
let city1 = "madrid";
let city2 = "rome";
let city3 = "athens";

$.getJSON("http://api.openweathermap.org/data/2.5/weather?q=" + city +"&units=metric&APPID=8d112e0c9ee011363d142ccc774fada7", 
function(data){

let icon = "https://openweathermap.org/img/w/" + data.weather[0].icon + ".png";
let temp =Math.floor(data.main.temp)+ " °C";
let weather = data.weather[0].main;

// $('.city1').append(city);
$('.icon').attr('src', icon);
$('.weather').append(weather)
$('.temp').append(temp);
});

$.getJSON("http://api.openweathermap.org/data/2.5/weather?q=" + city1 +"&units=metric&APPID=8d112e0c9ee011363d142ccc774fada7", 
function(data){

let icon = "https://openweathermap.org/img/w/" + data.weather[0].icon + ".png";
let temp =Math.floor(data.main.temp)+ " °C";
let weather = data.weather[0].main;

// $('.city1').append(city1);
$('.icon1').attr('src', icon);
$('.weather1').append(weather)
$('.temp1').append(temp);
});

$.getJSON("http://api.openweathermap.org/data/2.5/weather?q=" + city2 +"&units=metric&APPID=8d112e0c9ee011363d142ccc774fada7", 
function(data){

let icon = "https://openweathermap.org/img/w/" + data.weather[0].icon + ".png";
let temp =Math.floor(data.main.temp)+ " °C";
let weather = data.weather[0].main;

// $('.city1').append(city);
$('.icon2').attr('src', icon);
$('.weather2').append(weather)
$('.temp2').append(temp);
});

$.getJSON("http://api.openweathermap.org/data/2.5/weather?q=" + city3 +"&units=metric&APPID=8d112e0c9ee011363d142ccc774fada7", 
function(data){

let icon = "https://openweathermap.org/img/w/" + data.weather[0].icon + ".png";
let temp =Math.floor(data.main.temp)+ " °C";
let weather = data.weather[0].main;

// $('.city1').append(city1);
$('.icon3').attr('src', icon);
$('.weather3').append(weather)
$('.temp3').append(temp);
});

</script>
    <body>

        <div class="weather-container">
    
        <div style="float: left">
            <h4>Brussel</h4>
            <img class="icon">
            <p class="weather"></p>
            <p class="temp"></p>
        </div>
    
        <div  style="float: left">
            <h4>Madrid</h4>
            <img class="icon1">
            <p class="weather1"></p>
            <p class="temp1"></p>
        </div>
    
            <div  style="float: left">
            <h4>Rome</h4>
            <img class="icon2">
            <p class="weather2"></p>
            <p class="temp2"></p>
        </div>
    
            <div  style="float: left">
            <h4>Athene</h4>
            <img class="icon3">
            <p class="weather3"></p>
            <p class="temp3"></p>
        </div>
        </div>
    </body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/pages/weatherapi.blade.php ENDPATH**/ ?>