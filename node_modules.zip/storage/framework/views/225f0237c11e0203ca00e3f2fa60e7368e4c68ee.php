<?php $__env->startSection('content'); ?> 

<body style="background:url(https://cdn.pixabay.com/photo/2019/05/22/13/32/people-4221565_960_720.jpg);  background-repeat: no-repeat; background-size: cover;  background-position:  center;" >
        
        <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/blog/">
                <!-- Bootstrap core CSS -->
        <link href="/docs/4.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">  
        <link href="https://fonts.googleapis.com/css?family=Playfair+Display:700,900" rel="stylesheet">
        <link href="https://getbootstrap.com/docs/4.3/examples/blog/blog.css" rel="stylesheet">

     
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" type="text/css">



<header>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <!-- Slide One - Set the background image for this slide in the line below -->
        <div class="carousel-item active" style="background-image: url()">
          <div class="carousel-caption d-none d-md-block">
            <h2 class="display-4">First Slide</h2>
            <p class="lead">This is a description for the first slide.</p>
          </div>
        </div>
        <!-- Slide Two - Set the background image for this slide in the line below -->
        <div class="carousel-item" style="background-image: ">
          <div class="carousel-caption d-none d-md-block">
            <h2 class="display-4">Second Slide</h2>
            <p class="lead">This is a description for the second slide.</p>
          </div>
        </div>
        <!-- Slide Three - Set the background image for this slide in the line below -->
        <div class="carousel-item" style="background-image: ">
          <div class="carousel-caption d-none d-md-block">
            <h2 class="display-4">Third Slide</h2>
            <p class="lead">This is a description for the third slide.</p>
          </div>
        </div>
      </div>
     <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a> 
     </div> 
  </header>
  <br>

      <div class="blog-post">
          <h2 class="blog-post-title">Sample blog post</h2>
          <p class="blog-post-meta">January 1, 2014 by <a href="#">Mark</a></p>
  
          <p>This blog post shows a few different types of content that’s supported and styled with Bootstrap. Basic typography, images, and code are all supported.</p>
          <hr>
          <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
          <blockquote>
            <p>Curabitur blandit tempus porttitor. <strong>Nullam quis risus eget urna mollis</strong> ornare vel eu leo. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
          </blockquote>
          <p>Etiam porta <em>sem malesuada magna</em> mollis euismod. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.</p>
        </div><!-- /.blog-post -->


      <div class="row mb-2"> 
        <div class="col-md-6">
          <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            
            <?php $__currentLoopData = $randompost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col p-4 d-flex flex-column position-static" style="background-image: url('/storage/cover_images/<?php echo e($post->cover_image); ?>'); background-size: 100% 100%;">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <strong class="d-inline-block mb-2 text-primary"><h5 style="color:white;">From The Archive</h5></strong>
              <h3 class="mb-0"> 
                <?php $__currentLoopData = $randompost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a style="color:white;" href="/posts/<?php echo e($post->id); ?>"><?php echo e(str_limit($post->title, 15)); ?></a>
                  </h3>
              <div class="mb-1 text-muted">
                      <p style="color:white;">
                          Created <?php echo e($post->created_at->diffForhumans()); ?> <br>
                      </p>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                

                  <?php $__currentLoopData = $randompost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a href="/posts/<?php echo e($post->id); ?>" class="stretched-link" style="color:white;"><?php echo str_limit($post->body, 100); ?> <p>Read More</p></a>
                 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

            <div class="col-auto d-none d-lg-block">
              <svg class="bd-placeholder-img" width="200" height="250" xmlns="http://www.w3.org/2000/svg" 
              preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
              <title>Placeholder</title><rect width="100%" height="100%" fill="#74d8fc"/><text x="50%" y="50%" fill="#eceeef" 
              dy=".3em"></text></svg>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">

              <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col p-4 d-flex flex-column position-static" style="background-image: url('/storage/cover_images/<?php echo e($post->cover_image); ?>'); background-size: 100% 100%;">
              <strong class="d-inline-block mb-2 text-success"><h5 style="color:white;">New Post</h5></strong>
              <h3 class="mb-0"><a style="color:white;" href="/posts/<?php echo e($post->id); ?>"><?php echo e(str_limit($post->title, 15)); ?></a></h3>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="mb-1 text-muted">
                <p style="color:white;">
                    Created  <?php echo e($post->created_at->diffForhumans()); ?> <br>
                </p>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="/posts/<?php echo e($post->id); ?>" class="stretched-link" style="color:white;"><?php echo str_limit($post->body, 100); ?> <p>Read More</p></a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-auto d-none d-lg-block">
              <svg class="bd-placeholder-img" width="200" height="250" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice"
               focusable="false" role="img" aria-label="Placeholder: Thumbnail"><title>Placeholder</title><rect width="100%" height="100%" 
               fill="#74d8fc"/><text x="50%" y="50%" fill="#eceeef" dy=".3em"></text></svg>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <main role="main" class="container">
      <div class="row">
        <div class="col-md-8 blog-main">
          <h3 class="pb-4 mb-4 font-italic border-bottom">
            From the Firehose
          </h3>
    
         
    
          <div class="blog-post">
            <h2 class="blog-post-title">Another blog post</h2>
            <p class="blog-post-meta">December 23, 2013 by <a href="#">Jacob</a></p>
    
            <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
           
              <p>Curabitur blandit tempus porttitor. <strong>Nullam quis risus eget urna mollis</strong> ornare vel eu leo. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
              
              <h3 class="blog-post-title">Search for a country info</h3><br>
              
             <input  id="searchInput" type="text" name="name" placeholder="Country name"><br>
             <button id="modalBtn" class="button">Search</button>
     
             <div id="simpleModal" class="modal">
                 <div class="modal-content">
                     <span class="closeBtn">&times;</span>
                 <ul>
                     <li id="par"></li>
                     <li id="par1"></li>
                     <li id="par2"></li>
                     <li id="par3"></li>
                     <li id="par4"></li>
                     <li id="par5"></li>
                 </ul>
                 </div>
             </div>
             
            </div><!-- /.blog-post -->
          
        </div><!-- /.blog-main -->
              
          <aside class="col-md-4 blog-sidebar">
            <div class="p-4 mb-3 bg-light rounded">

                      <ul >
                        <li id="name" style="font-size: 13px;"></li>
                        <li><img id="icon"></li>
                        <li id="desc" style="font-size: 12px;"></li>
                        <li id="temp"></li>
                      <hr>
                        <li id="name1" style="font-size: 13px;"></li>
                        <li><img id="icon1"></li>
                        <li id="desc1" style="font-size: 12px;"></li>
                        <li id="temp1"></li>
                      <hr>
                        <li id="name2" style="font-size: 13px;"></li>
                        <li><img id="icon2"></li>
                        <li id="desc2" style="font-size: 12px;"></li>
                        <li id="temp2"></li>
                    <hr>
                        <li id="name3" style="font-size: 13px;"></li>
                        <li><img id="icon3"></li>
                        <li id="desc3" style="font-size: 12px;"></li>
                        <li id="temp3"></li>
                    </ul>
          </div>
        </aside><!-- /.blog-sidebar -->
      </div><!-- /.row -->
      
      <script type="text/javascript" src="<?php echo e(asset('js/weather.api.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('js/country.js')); ?>"></script>
    </main><!-- /.container -->
    </body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/pages/index.blade.php ENDPATH**/ ?>