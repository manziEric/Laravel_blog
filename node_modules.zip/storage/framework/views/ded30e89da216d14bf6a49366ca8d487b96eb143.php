<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\lsapp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>