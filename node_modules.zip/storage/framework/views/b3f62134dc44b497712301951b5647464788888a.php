<?php $__env->startSection('content'); ?>
 
 <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" type="text/css"> 
<body style="background:url(https://images.pexels.com/photos/373076/pexels-photo-373076.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940);  background-repeat: no-repeat; background-size: cover;  background-position:  center;">
  <br>
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="image-aboutus-banner">
               
        <div class="card mb-4 shadow-sm" style="width: 1080px;" >
        <div class="card-header">
        <br>
      </div>
      <div class="card-body">
        <ul class="list-unstyled mt-3 mb-4">
        <h1 class="lg-text">About Us</h1>
        <p class="image-aboutus-para">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        <p class="image-aboutus-para">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. 
          Incidunt aliquid pariatur quis saepe odit amet, 
          nihil perferendis assumenda aspernatur accusantium dignissimos minus,
           ab sapiente eaque, quam delectus 
          quia distinctio atque.A eveniet debitis sapiente tenetur earum temporibus
           ullam esse, quos rerum numquam
           nostrum impedit repellendus nam ipsa quis, enim ab dicta ex id.
            Alias, voluptates voluptatum autem 
           corrupti quae officia.
          </p>
          <p class="image-aboutus-para">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. 
              Incidunt aliquid pariatur quis saepe odit amet, 
              nihil perferendis assumenda aspernatur accusantium dignissimos minus,
               ab sapiente eaque, quam delectus 
              quia distinctio atque.A eveniet debitis sapiente tenetur earum temporibus
               ullam esse, quos rerum numquam
               nostrum impedit repellendus nam ipsa quis, enim ab dicta ex id.
                Alias, voluptates voluptatum autem 
               corrupti quae officia.
              </p>      
        </ul>
        <button class="btn btn-lg btn-block btn-primary"><a href="http://"><br></a></button>
      </div>
    </div>
            </div>
        </div>
    </div>
</div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/pages/about.blade.php ENDPATH**/ ?>